/**
 * Author: Khoa Phan
 * Course: CS146-06
 * Description: The program simulates a hospital waiting room using red black tree.
 * Simulations: 	
 * BST functions:
 * 					Build up a BST full of 20 patients.
 * 					Insert a patient with priority to the red black tree.
 * 					Search a patient based on priority number.
 * 					Delete a patient with priority to the red black tree.
 * 					Sorted the list in ascending order.
 */

import java.util.Scanner;
import java.awt.Color;

public class PA3 
{
	private static int roomCapacity = 20; // default room always maintain at 20 people.
	private static Scanner input;
	private static int rbtreeSize = 0;
	private static redblackNode x, y, w;
	private static redblackTree waitingroom = new redblackTree(); // create an empty BST.
	
	public static void main(final String[] args)
	{
		String name; // hold name
		int priority ; // hold priority
		char repeat = 'r'; // repeat the menu
		redblackNode Node; //hold node of the tree
		
		 
		
		input = new Scanner(System.in);
		
		
		String[] names = { "Dung", "Phuc", "Ryan", "Aron", "Kris","Jenny", "Bob", "Jason",
	            "Vivian", "Julian", "Vinh", "Julie", "Jacob", "Kevin", "Rose", "Jack",  "Katy",
	            "Alissa", "Tom", "Jerry", "Malvin", "Justin", "Lee", "Zhang", "Fa", "Bel",  "Ella",
	            "Austin", "Zac", "Jake", "Logan", "Ken"};
		
		
		
		Patient[] patientArray = new Patient[roomCapacity]; // hold patient name and priority 
		for(int i = 0; i < roomCapacity; i++)
        {
			patientArray[i] = new Patient(names[i], (i+1)); 
        }
		
		do
		{
			System.out.println("\t\t\tWelcome to Hospital waiting room");    	        
		    System.out.println("**********************************************************************");	
		    System.out.println("\t\t\t\t Menu ");
		    System.out.println("1. Build up a Patients Red Black Tree");
			System.out.println("2. Insert a patient to the RB Treebased on his/her priority code.");
			System.out.println("3. Search a patient's name by entering a priority code.");
			System.out.println("4. Delete apatient from the RB Tree.");
			System.out.println("5. Make a sorted list of patients based onthe priority codes.");
			System.out.println("0. Exit");
			System.out.print("Please choose an option that you want to operate (0-5): ");
		
			switch (input.nextInt()) //menu
		    {
		    case 1: //build red black tree with 20 patients
		    	if (waitingroom.getSize() > 0 )
		    	{
		    		System.out.println("The red black Tree is already built up");
                    break;
		    	}
		    	else
		    		for (int i = 0; i < roomCapacity; i++)
					{
						Node = new redblackNode(patientArray[i]);
						insert(waitingroom, Node);
					}
		    	
		    	waitingroom.inOrder();
				break;
				
				
		    case 2: //insert a new patient
		    	if(waitingroom.getSize() == 20)
				{
				System.out.println("The waiting room is full of 20 people");
				System.out.println("Please delete one patient out of the waiting room first");
				}
			else							
				{
					System.out.print("Enter name of new patient: ");
					name = input.next();							
					System.out.print("Enter new priority(0<priority): ");
					priority = input.nextInt();	
					int index = 0;
					if(priority > 0) 
					{
					Patient patientInfo = new Patient(name, priority);
					if(patientArray[index].getPriority() < priority) //check if the priority number is duplicated
		 				checkduplicate(patientArray, index, priority);
					insert(waitingroom, new redblackNode(patientInfo));
					System.out.println(patientInfo.toString());
					System.out.println("The waiting room have been updated");
					waitingroom.inOrder(redblackTree.getRoot());	
					}
					else
					{
						System.out.println("Please enter a priority number greater than 0");
					}
				}
		break;
		    
		    case 3: //search a patient based on priority number
		    	
		    	if (waitingroom.getSize() != 0)
		    	{
		    		System.out.print("Enter priority code of patient you want to find: ");
					priority = input.nextInt();
					Node = search(redblackTree.getRoot(), new Patient(null, priority));
					if (Node != waitingroom.getNil())
					{
						System.out.println("Name of the patient with selected priority is : " + Node.toString());
					}
					else
					{
						System.out.println("The patient you entered is not in the waiting list.");
						System.out.println("Please make sure the patient's priority is correct");
						
					}
		    	}
		    	else
		    	{
		    		System.out.println("The waiting room is empty");
		    	}
		    	break;
		    		
		    	
		    case 4: //delete a patient based on priority number
		    	if (waitingroom.getSize() == 0)
				{
					System.out.println("The list of patients is empty so you cannot do the delete operation.");
				}
		    	else if (waitingroom.getSize() < 20 && waitingroom.getSize() != 0)
				{
					System.out.println("You can only delete one patient at a time");
					System.out.println("You need to add a new patient to make the list full of 20 patients.");
				}
		    	else
		    	{
		    		System.out.println("****************************************************************");
					waitingroom.inOrder(redblackTree.getRoot());
					System.out.print("Please enter the priority number of the patient you want to delete: ");
					priority = input.nextInt();
					Node = search(redblackTree.getRoot(), new Patient(null, priority));
		    	
					if (Node == waitingroom.getNil())
						System.out.println("The priority number you entered " + priority +  " does not existed.");
					else
					{							
						delete(waitingroom, Node);							
						System.out.println("The patient with the selected priority is deleted: ");
						System.out.println(Node.toString());
						System.out.println("The waiting room have been updated");
						waitingroom.inOrder(redblackTree.getRoot());				
					}
		    	}
		    	break;
		    	
		    case 5: // make a list of patients
		    	if (waitingroom.getSize() != 0)
		    	{
		    		System.out.println("The acesding sorted list is: \n");
		    		waitingroom.inOrder(redblackTree.getRoot());	
		    	}
		    	else
		    	{
		    		System.out.println("The waiting list is empty");
		    	}
		    	break;
		    	
		    case 0: //exit the program
		    	System.out.println("Program is closed");
		    	break;
		    	default: // return menu if user entered the option that is not in the list  
		    		System.out.println("Please choose from 0 to 6");
		    	
		    }
		}
		while (repeat != '$');
	}	
	
	/**
	 * avoid two or more patients to have same priority
	 * @param array a Patient array
	 * @param index an Integer representing an index of patient
	 * @param priority an Integer representing a priority of patient
	 */	
	private static void checkduplicate(Patient[] patientArray, int index, int priority )
	{
		
		for(int i = 0; i<roomCapacity; i++) 
		{
			if(i != index && patientArray[i].getPriority() == priority)
			{
				patientArray[i].setPriority(patientArray[i].getPriority() +1 );
				checkduplicate(patientArray, i, patientArray[i].getPriority());
			}
		}
	}
	
	
	public static class redblackTree
	{
		static redblackNode root;
		static redblackNode nil;
		
		// create a default red black tree
		public redblackTree()
		{
			nil = new redblackNode(new Patient());
			nil.patientColor = Color.BLACK;
			root = nil;
		}
		
		
		
		
		
		/**
		 * make a list of red black tree with increasing sorted priority
		 */
		public void inOrder()
		{
			inOrder(redblackTree.root);
		}
		
		public void inOrder(redblackNode x)
		{
	        if(x != redblackTree.nil)
	        {
	            inOrder(x.left);
	            System.out.println(x.toString());	            
	            inOrder(x.right);
	        }
	
		}	
		
		/**
		 * getter size 
		 * @return size 
		 */
		public int getSize()
		{
			return rbtreeSize;
		}
		
		/**
		 * getter root 
		 * @return root 
		 */
		
		public static redblackNode getRoot()
		{
			return root;
		}
		
		/**
		 * getter nil
		 * @return T.nil
		 */
		public redblackNode getNil()
		{
			return nil;
		}
	}	
	
	
	/**
	 * Left rotate at x	
	 * @param T
	 * @param x
	 */
	public static void LeftRotate(redblackTree T, redblackNode x)
		{
			 y = x.right; //Set y
			x.right = y.left; //Turn y�s left subtree into x�s right subtree.
			if (y.left != redblackTree.nil)
				y.left.parent = x;
			y.parent = x.parent; // Link x�s parent to y.
			if (x.parent == redblackTree.nil)
				redblackTree.root = y;
			else if (x == x.parent.left)
				x.parent.left = y;
			else x.parent.right = y;
			y.left = x; // Put x on y�s left.
			x.parent = y;
		}
	
	/**
	 * Right rotate at x
	 * @param T 
	 * @param x 
	 */
	public static void RightRotate(redblackTree T, redblackNode x)
		{
			 y = x.left;// Set y
			x.left = y.right; //Turn y�s right subtree into x�s left subtree.
			if (y.right != redblackTree.nil)
				y.right.parent = x;
			y.parent = x.parent; // Link x�s parent to y.
			if (x.parent == redblackTree.nil)
				redblackTree.root = y;
			else if (x == x.parent.right)
				x.parent.right = y;
			else x.parent.left = y;
			y.right = x; // Put x on y�s right.
			x.parent = y;
		}
		
	/**
	 * swap nodes
	 * @param T red black tree 
	 * @param u node will be delete
	 * @param v node will move 
	 */
	public static void Transplant(redblackTree T, redblackNode u, redblackNode v)
		{
			/* Handle u is root of T */
			if (u.parent == redblackTree.nil)
				redblackTree.root = v;
			/* if u is a left child */
			else if (u == u.parent.left)
				u.parent.left = v;
			/* if u is a right child */
			else u.parent.right = v;
			v.parent = u.parent;
		}
		
		
		
	/**
	 * find minimum node of x
	 * @param x is a node of the red black tree
	 * @return minimum node of x
	 */	
		
	public static redblackNode Minimum(redblackTree T, redblackNode x)
		{
			while (x.left != redblackTree.nil)
				x = x.left;
			return x;
		}
		
		
		
	/**
	 * insert node z to T	
	 * @param T red black tree
	 * @param z new node
	 */
	public static void insert(redblackTree T, redblackNode z)
		{
			redblackNode y = redblackTree.nil; /* trailing pointer, parent of x */
			redblackNode x = redblackTree.root;
			
			while (x != redblackTree.nil)
			{
				y = x;
				if (z.key.getPriority() < x.key.getPriority())
					x = x.left;
				else
					x = x.right;
				
			}
			z.parent = y;
			if (y == redblackTree.nil)
				redblackTree.root = z; /* tree T was empty */
			else if (z.key.getPriority() < y.key.getPriority())
				y.left = z;
			else
				y.right = z;
			z.left = redblackTree.nil;
			z.right = redblackTree.nil;
			z.patientColor = Color.RED;
			rbtreeSize++;
			insertFixup(T, z);
		}
		
	/**
	 * fix-up color of T when insert z
	 * @param T red black tree
	 * @param z new node
	 */
	public static void insertFixup(redblackTree T, redblackNode z)
		{
			while (z.parent.patientColor == Color.RED)
			{
				if (z.parent == z.parent.parent.left)
				{
					y = z.parent.parent.right; // y now is z�s uncle
					if (y.patientColor == Color.RED)
					{
						z.parent.patientColor = Color.BLACK; //Case 1
						y.patientColor = Color.BLACK; //Case 1
						z.parent.parent.patientColor = Color.RED; //Case 1
						z = z.parent.parent; //Case 1
					}
					else 
					{
						if (z == z.parent.right) //y.patientColor != RED
						{
							z = z.parent; //Case 2
							LeftRotate(T, z); //Case 2
						}
						z.parent.patientColor = Color.BLACK; //Case 3
						z.parent.parent.patientColor = Color.RED; //Case 3
						RightRotate(T, z.parent.parent); //Case 3
					}
				}
				else 
				{
					y = z.parent.parent.left;  // y now is z�s uncle
					if (y.patientColor == Color.RED)
					{
						z.parent.patientColor = Color.BLACK; //Case 1
						y.patientColor = Color.BLACK; //Case 1
						z.parent.parent.patientColor = Color.RED; //Case 1
						z = z.parent.parent; //Case 1
					}
					else 
					{
						if (z == z.parent.left)  //y.patientColor != RED
						{
							z = z.parent;  //Case 2
							RightRotate(T, z);  //Case 2
						}
						z.parent.patientColor = Color.BLACK; //Case 3
						z.parent.parent.patientColor = Color.RED; //Case 3
						LeftRotate(T, z.parent.parent); //Case 3
					}
				}
			}
			redblackTree.root.patientColor = Color.BLACK;
		}
		
	/**
	 * delete z	out of T
	 * @param T red black tree
	 * @param z node will be deleted
	 */
	public static void delete(redblackTree T, redblackNode z) 
		{
			y = z;
			Color y_original_color = y.patientColor;
			if (z.left == redblackTree.nil)
			{
				x = z.right;
				Transplant(T, z, z.right);
			}
			else if (z.right == redblackTree.nil)
			{
				x = z.left;
				Transplant(T, z, z.left);
			}
			else 
			{
				y = Minimum(T, z.right); //z has two children
				y_original_color = y.patientColor;
				x = y.right;
				if (y.parent == z)
					x.parent = y;
				else
				{
					Transplant(T, y, y.right);
					y.right = z.right;
					y.right.parent = y;
				}
				Transplant(T, z, y);
				y.left = z.left;
				y.left.parent = y;
				y.patientColor = z.patientColor;
			}
			rbtreeSize--;
			if (y_original_color == Color.BLACK)
				deleteFixup(T, x);
		}
	
	/**
	 * fix-up x color of T 
	 * @param T red black Tree
	 * @param x node will be fix
	 */
	public static void deleteFixup(redblackTree T, redblackNode x)
		{
			while (x != redblackTree.root && x.patientColor == Color.BLACK)
			{
				if (x == x.parent.left)
				{
					w = x.parent.right;
					if (w.patientColor == Color.RED)
					{
						w.patientColor = Color.BLACK; //Case 1
						x.parent.patientColor = Color.RED; //Case 1
						LeftRotate(T, x.parent); //Case 1
						w = x.parent.right; //Case 1
					}
					if (w.left.patientColor == Color.BLACK && w.right.patientColor == Color.BLACK) // x is still x.parent.left
					{
						w.patientColor = Color.RED; //Case 2
						x = x.parent; //Case 2
					}
					else
					{
						if (w.right.patientColor == Color.BLACK)
						{
							w.left.patientColor = Color.BLACK; //Case 3
							w.patientColor = Color.RED; //Case 3
							RightRotate(T, w); //Case 3
							w = x.parent.right; //Case 3
						}
						w.patientColor = x.parent.patientColor; //Case 4
						x.parent.patientColor = Color.BLACK; //Case 4
						w.right.patientColor = Color.BLACK; //Case 4
						LeftRotate(T, x.parent); //Case 4
						x = redblackTree.root; //Case 4
					}
				}
				else
				{
					w = x.parent.left;
					if (w.patientColor == Color.RED)
					{
						w.patientColor = Color.BLACK; //Case 1
						x.parent.patientColor = Color.RED; //Case 1
						RightRotate(T, x.parent); //Case 1
						w = x.parent.left; //Case 1
					}
					if (w.right.patientColor == Color.BLACK && w.left.patientColor == Color.BLACK) // x is still x.parent.right
					{
						w.patientColor = Color.RED; //Case 2
						x = x.parent; //Case 2
					}
					else
					{
						if (w.left.patientColor == Color.BLACK)
						{
							w.right.patientColor = Color.BLACK; //Case 3
							w.patientColor = Color.RED; //Case 3
							LeftRotate(T, w); //Case 3
							w = x.parent.left; //Case 3
						}
						w.patientColor = x.parent.patientColor; //Case 4
						x.parent.patientColor = Color.BLACK; //Case 4
						w.left.patientColor = Color.BLACK; //Case 4
						RightRotate(T, x.parent); //Case 4
						x = redblackTree.root; //Case 4
					}
				}
			}
			x.patientColor = Color.BLACK;
		}
	
	/**
	 * search k 
	 * @param x root of red black tree
	 * @param k patient that needed to find
	 * @return node or nil
	 */
	public static redblackNode search(redblackNode x, Patient k)
		{
			 if(x == redblackTree.nil || k.getPriority() == x.key.getPriority())
	            return x;
	        else if(k.getPriority() < x.key.getPriority())
	            return search(x.left, k);
	        else
	            return search(x.right, k);
	    }
		
		
		
		
		
	
	// a class represent nodes of the red black tree
	public static class redblackNode
	{
		private Patient key;
		private redblackNode left, right, parent;
		private Color patientColor;
				
		/**
		 * create a class node contain color & key
		 * @param currentPatient 
		 * @param node with patient's key & color
		 */
        public redblackNode(Patient currentPatient)
        {
            key = currentPatient;
        }
	
		
		/**
		 * print the patient's information with color
		 */
		public String toString()
		{
			String cl;
			if (patientColor != Color.BLACK)
			{
				cl = "Red";
			}
			else
			{
				cl = "Black";	
			}
			return this.key.toString() + "\tColor: " + cl;
		}
		
	}
	
	
	/**
	 * A class representing patients with their names and priority numbers
	 */
	
	public static class Patient
	{

		String patientName;
		int priorityNumber;		

		/**
		 * Constructor: requires specific name and priority
		 * @param name a String representing a name of patient
		 * @param priority an Integer representing a priority number of patient
		 */
		public Patient(String name, int priority)
		{
			this.patientName = name;
			this.priorityNumber = priority;
			
		}

		/**
		 * Constructor: requires nothing
		 */
		public Patient()
		{
		}

		/**
		 * Sets a name to this patient
		 * @param name a String representing a name of patient
		 */
		public void setPatientName(String name)
		{
			this.patientName = name;
		}

		/**
		 * Sets a priority number to this patient
		 * @param priority an Integer representing a priority number of patient
		 */
		public void setPriority(int priority)
		{
			this.priorityNumber = priority;
		}

		/**
		 * Returns the name of this patient
		 * @return the name of patient
		 */
		public String getPatientName()
		{
			return patientName;
		}

		/**
		 * Returns the priority number of this patient
		 * @return the priority number of this patient
		 */
		public int getPriority()
		{
			return priorityNumber;
		}

		/**
		 * Returns a String representation of this patient
		 * @return a String representation of this patient
		 */
		public String toString()
		{
			return "Patient:" + this.patientName + "\tPriority number: " + this.priorityNumber;
		}			
		
	}
}

